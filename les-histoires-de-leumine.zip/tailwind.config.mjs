/** @type {import('tailwindcss').Config} */
export default {
	content: ["./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}", "*.{js,ts,jsx,tsx,mdx}"],
	theme: {
		extend: {
			colors: {
				primary: {
					DEFAULT: '#e91e63', // Rose/Pink
					dark: '#c2185b',
					light: '#f48fb1',
				},
				secondary: {
					DEFAULT: '#9c27b0', // Purple
					dark: '#7b1fa2',
					light: '#ce93d8',
				},
			},
			fontFamily: {
				sans: ['Poppins', 'sans-serif'],
			},
		},
	},
	plugins: [
		require('@tailwindcss/typography'),
	],
}

