"use client"

import LogoutButton from "../src/components/LogoutButton"

export default function SyntheticV0PageForDeployment() {
  return <LogoutButton />
}