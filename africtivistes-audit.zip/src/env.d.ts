/// <reference types="astro/client" />

